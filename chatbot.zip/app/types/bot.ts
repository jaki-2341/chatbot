export interface Bot {
  id: string;
  name: string;
  agentName: string;
  welcomeMessage: string;
  primaryColor: string;
  position: 'bottom-left' | 'bottom-right';
  role?: string; // Role/tag displayed in header (e.g., "Customer Support Agent")
  inputPlaceholder?: string; // Placeholder text for the chat input field
  widgetIcon?: 'message-circle' | 'bot' | 'sparkles' | 'help-circle'; // Widget icon type
  showAvatarOnButton?: boolean; // Show avatar image on floating button instead of icon
  knowledgeBase?: string;
  files?: (File | string)[]; // Can be File objects (in memory) or strings (serialized)
  avatarImage?: string; // Base64 encoded image or image URL
  previewUrl?: string; // Website URL for preview iframe
  status?: 'Active' | 'Inactive'; // Bot status for dashboard
  welcomeDescription?: string; // Secondary welcome text
  suggestedQuestions?: string[]; // Array of quick starter questions
  colorHistory?: (string | null)[]; // Color palette history (6 slots)
  collectInfoEnabled?: boolean; // Enable information collection
  leadReceiverEmail?: string; // Email address to receive collected leads
  collectEmail?: boolean; // Collect email address
  collectName?: boolean; // Collect full name
  collectPhone?: boolean; // Collect phone number
  ctaEnabled?: boolean; // Enable CTA bubble above chatbot button
  ctaStatus?: string; // Status text (e.g., "ONLINE")
  ctaText?: string; // CTA text (e.g., "Chat with Audrey")
  createdAt?: Date;
  updatedAt?: Date;
}

export const COLORS = [
  '#3B82F6',
  '#10B981',
  '#8B5CF6',
  '#F59E0B',
  '#EF4444',
  '#EC4899',
  '#111827',
];

export const INITIAL_BOTS: Bot[] = [
  {
    id: 'bot_123abc',
    name: 'Customer Support',
    agentName: 'Sarah',
    welcomeMessage: 'Hi there! How can I help you today?',
    primaryColor: '#3B82F6',
    position: 'bottom-right',
    knowledgeBase: 'We sell cloud automation tools. Our business hours are Mon-Fri 9AM-5PM EST. Support email is help@company.com. Pricing starts at $29/mo.',
  },
  {
    id: 'bot_456def',
    name: 'Sales Assistant',
    agentName: 'Alex',
    welcomeMessage: 'Looking for the best deal? Let me help!',
    primaryColor: '#10B981',
    position: 'bottom-left',
    knowledgeBase: 'We are currently offering a 20% discount on all annual plans. Code: SAVE20. Our enterprise plan includes 24/7 priority support.',
  },
];

